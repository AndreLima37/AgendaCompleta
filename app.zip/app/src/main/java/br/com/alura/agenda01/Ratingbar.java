package br.com.alura.agenda01;

/**
 * Created by DELL on 19/09/2017.
 */

class Ratingbar {
}
